from __future__ import absolute_import
from htchirp import client
import sys

sys.exit(client.main())