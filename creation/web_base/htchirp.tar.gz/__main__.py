# SPDX-FileCopyrightText: 2009 Fermi Research Alliance, LLC
# SPDX-License-Identifier: Apache-2.0

from __future__ import absolute_import
from htchirp import client
import sys

sys.exit(client.main())
